/* ====================================
File name: exerc_1_0.c
Date: 2020-01-26
Group 30
Members that contribute to the solutions
Hjalmar Thunberg
Christian O'Neill
Hugo Hempel
Member not present at demonstration time:
-----
Demonstration code: [6798]
====================================== */
#include <stdio.h>

int main(void) {
    printf("Hello World!");
    return 0;
}